from __future__ import annotations

import numpy as np
import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import os
import json
from typing import Tuple, List, Dict, Any
import warnings

warnings.filterwarnings('ignore')

# MNIST lOADING
from sklearn.datasets import fetch_openml

def load_mnist_data():

    mnist = fetch_openml('mnist_784', version=1, parser='auto')
    X = mnist.data.astype('float32')
    y = mnist.target.astype('int64')
    X_train = X[:60000]
    y_train = y[:60000]
    X_test = X[60000:]
    y_test = y[60000:]
    return (X_train, y_train), (X_test, y_test)

OUTPUT_DIR = 'ME-train'
os.makedirs(OUTPUT_DIR, exist_ok=True)


class MEModel:
    """Neuromorphic ME system"""

    def __init__(self) -> None:
        # LTP
        self.gp: float = 0.086312
        self.g0_ltp: float = 1.0808
        self.v_ltp: float = 1.869004
        # LTD
        self.gd: float =  0.001267
        self.g0_ltd: float = 0.7719
        self.v_ltd: float = 0.830248
        # normalization
        self.n_min: float = 0.0
        self.n_max: float = 1.0

    def ltp_function(self, n: np.ndarray) -> np.ndarray:
        """
        LTP
        Gp(n)=Gp+G0×(1-exp(-v×n))
        """
        n_clipped = np.clip(n, self.n_min, self.n_max)
        result = self.gp + self.g0_ltp * (1.0 - np.exp(-self.v_ltp * n_clipped))
        return result

    def ltd_function(self, n: np.ndarray) -> np.ndarray:
        """
        LTD
        Gd(n)=Gd-G0×(1-exp(-v×(n-1)))
        """
        n_clipped = np.clip(n, self.n_min, self.n_max)
        result = self.gd - self.g0_ltd * (1.0 - np.exp(-self.v_ltd * (n_clipped - 1.0)))
        return result

    def gradient_to_normalized_pulses(self, gradient: np.ndarray) -> np.ndarray:
        abs_gradient = np.abs(gradient)
        max_gradient = 0.1
        pulses_0_to_100 = np.clip(abs_gradient / max_gradient * 100.0, 0.0, 100.0)
        normalized_pulses = pulses_0_to_100 / 100.0
        return normalized_pulses

    def apply_weight_update(self,
                            current_weight: np.ndarray,
                            gradient: np.ndarray,
                            learning_rate: float = 0.01) -> np.ndarray:

        normalized_pulses = self.gradient_to_normalized_pulses(gradient)
        weight_change = np.zeros_like(gradient, dtype=np.float64)

        ltp_mask = gradient < 0
        if np.any(ltp_mask):
            ltp_pulses = normalized_pulses[ltp_mask]
            g_before = self.ltp_function(np.zeros_like(ltp_pulses))
            g_after = self.ltp_function(ltp_pulses)
            delta_g = g_after - g_before
            weight_change[ltp_mask] = delta_g * learning_rate * 0.01

        ltd_mask = gradient > 0
        if np.any(ltd_mask):
            ltd_pulses = normalized_pulses[ltd_mask]
            g_before = self.ltd_function(np.zeros_like(ltd_pulses))
            g_after = self.ltd_function(ltd_pulses)
            delta_g = g_after - g_before
            weight_change[ltd_mask] = delta_g * learning_rate * 0.01

        return current_weight + weight_change


def plot_ltp_ltd_curves(me: MEModel) -> None:
    n_values = np.linspace(0, 1, 1000)
    ltp_values = me.ltp_function(n_values)
    ltd_values = me.ltd_function(n_values)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    # LTP
    ax1.plot(n_values, ltp_values, 'b-', linewidth=2)
    ax1.set_xlabel('Normalized Pulse Number n [0, 1]', fontsize=12)
    ax1.set_ylabel('ME-ltp', fontsize=12)
    ax1.set_title('LTP Curve', fontsize=14, fontweight='bold')
    ax1.grid(True, alpha=0.3)

    # LTD
    ax2.plot(n_values, ltd_values, 'r-', linewidth=2)
    ax2.set_xlabel('Normalized Pulse Number n [0, 1]', fontsize=12)
    ax2.set_ylabel('ME-ltd', fontsize=12)
    ax2.set_title('LTD Curve', fontsize=14, fontweight='bold')
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    save_path = os.path.join(OUTPUT_DIR, 'LTP_LTD_curves.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close(fig)


class MENeuralNetwork:
    """784 × 128 × 10"""

    def __init__(self,
                 input_size: int = 784,
                 hidden_size: int = 128,
                 output_size: int = 10) -> None:
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

        # Xavier initialization
        self.w1 = np.random.randn(input_size, hidden_size).astype(np.float64) * np.sqrt(2.0 / input_size)
        self.b1 = np.zeros((1, hidden_size), dtype=np.float64)
        self.w2 = np.random.randn(hidden_size, output_size).astype(np.float64) * np.sqrt(2.0 / hidden_size)
        self.b2 = np.zeros((1, output_size), dtype=np.float64)

        self. me= MEModel()

        self.z1: np.ndarray = np.array([])
        self.a1: np.ndarray = np.array([])
        self.z2: np.ndarray = np.array([])
        self.a2: np.ndarray = np.array([])

    @staticmethod
    def relu(x: np.ndarray) -> np.ndarray:
        """ReLU"""
        return np.maximum(0.0, x)

    @staticmethod
    def relu_derivative(x: np.ndarray) -> np.ndarray:
        return np.where(x > 0, 1.0, 0.0)

    @staticmethod
    def softmax(x: np.ndarray) -> np.ndarray:
        """Softmax"""
        exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)

    def forward(self, x: np.ndarray) -> np.ndarray:
        self.z1 = np.dot(x, self.w1) + self.b1
        self.a1 = self.relu(self.z1)
        self.z2 = np.dot(self.a1, self.w2) + self.b2
        self.a2 = self.softmax(self.z2)
        return self.a2

    def compute_loss(self, y_pred: np.ndarray, y_true: np.ndarray) -> float:
        batch_size = y_true.shape[0]
        row_indices = np.arange(batch_size)
        selected_probs = y_pred[row_indices, y_true]
        log_likelihood = -np.log(selected_probs + 1e-8)
        loss = np.sum(log_likelihood) / batch_size
        return float(loss)

    def backward(self, x: np.ndarray, y_true: np.ndarray, learning_rate: float = 0.01,
                 l2_lambda: float = 0.0001) -> None:
        batch_size = x.shape[0]
        delta2 = self.a2.copy()
        row_indices = np.arange(batch_size)
        delta2[row_indices, y_true] -= 1.0
        delta2 = delta2 / batch_size
        dw2 = np.dot(self.a1.T, delta2)
        db2 = np.sum(delta2, axis=0, keepdims=True)
        delta1 = np.dot(delta2, self.w2.T) * self.relu_derivative(self.z1)
        dw1 = np.dot(x.T, delta1)
        db1 = np.sum(delta1, axis=0, keepdims=True)


        dw2 += l2_lambda * self.w2
        dw1 += l2_lambda * self.w1

        # ME-weight
        self.w2 = self.me.apply_weight_update(self.w2, dw2, learning_rate)
        self.b2 = self.me.apply_weight_update(self.b2, db2, learning_rate)
        self.w1 = self.me.apply_weight_update(self.w1, dw1, learning_rate)
        self.b1 = self.me.apply_weight_update(self.b1, db1, learning_rate)

    def train(self,
              x_train: np.ndarray,
              y_train: np.ndarray,
              x_test: np.ndarray,
              y_test: np.ndarray,
              epochs: int = 350,
              batch_size: int = 512,
              learning_rate: float = 0.12) -> Tuple[List[float], List[float], List[float], List[float]]:

        train_losses, train_accuracies = [], []
        test_losses, test_accuracies = [], []

        n_samples = x_train.shape[0]
        n_batches = n_samples // batch_size

        initial_lr = learning_rate

        for epoch in range(epochs):
            if epoch < 150:
                current_lr = initial_lr
            else:
                current_lr = initial_lr * (0.5 ** ((epoch - 150) // 50))
            current_l2 = 0.0001 if epoch < 200 else 0.0005

            shuffle_indices = np.random.permutation(n_samples)
            x_shuffled = x_train[shuffle_indices]
            y_shuffled = y_train[shuffle_indices]

            epoch_loss_sum = 0.0
            for batch_idx in range(n_batches):
                start_idx = batch_idx * batch_size
                end_idx = start_idx + batch_size
                x_batch = x_shuffled[start_idx:end_idx]
                y_batch = y_shuffled[start_idx:end_idx]

                y_pred_batch = self.forward(x_batch)
                epoch_loss_sum += self.compute_loss(y_pred_batch, y_batch)
                self.backward(x_batch, y_batch, current_lr, current_l2)

            avg_train_loss = epoch_loss_sum / n_batches
            train_pred = self.predict(x_train)
            train_acc = float(np.mean(train_pred == y_train))

            test_pred = self.predict(x_test)
            test_acc = float(np.mean(test_pred == y_test))
            y_pred_test = self.forward(x_test)
            test_loss = self.compute_loss(y_pred_test, y_test)

            train_losses.append(avg_train_loss)
            train_accuracies.append(train_acc)
            test_losses.append(test_loss)
            test_accuracies.append(test_acc)

            print(f"Epoch {epoch + 1:2d}/{epochs} - "
                  f" Train Acc: {train_acc:.4f} ", f" Test Acc: {test_acc:.4f}")

        return train_losses, train_accuracies, test_losses, test_accuracies

    def predict(self, x: np.ndarray) -> np.ndarray:
        probabilities = self.forward(x)
        predictions = np.argmax(probabilities, axis=1)
        return predictions


def plot_training_curves(train_accuracies: List[float],
                         test_accuracies: List[float]) -> None:
    num_epochs = len(train_accuracies)
    epoch_numbers = list(range(1, num_epochs + 1))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    #TRAIN
    ax1.plot(epoch_numbers, train_accuracies, 'b-', label='Train Accuracy', linewidth=2)
    ax1.set_xlabel('Epoch', fontsize=12)
    ax1.set_ylabel('Loss', fontsize=12)
    ax1.legend(fontsize=11)
    ax1.grid(True, alpha=0.3)

    #TEST
    ax2.plot(epoch_numbers, test_accuracies, 'r-', label='Test Accuracy', linewidth=2)
    ax2.set_xlabel('Epoch', fontsize=12)
    ax2.set_ylabel('Accuracy', fontsize=12)
    ax2.legend(fontsize=11)
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    save_path = os.path.join(OUTPUT_DIR, 'Accuracy_curves.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close(fig)



def plot_confusion_matrix_heatmap(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    cm = confusion_matrix(y_true, y_pred)

    fig, ax = plt.subplots(figsize=(10, 8))

    class_labels = [f'{i}' for i in range(10)]
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=True,
                xticklabels=class_labels, yticklabels=class_labels, ax=ax)

    ax.set_xlabel('Predicted Label', fontsize=12)
    ax.set_ylabel('True Label', fontsize=12)
    ax.set_title('Confusion Matrix', fontsize=14, fontweight='bold')

    plt.tight_layout()
    save_path = os.path.join(OUTPUT_DIR, 'confusion_matrix.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close(fig)

    return cm


def main() -> None:
    print("ME-based Neural Network Training System")
    print("Architecture: 784 × 128 × 10")
    print("\n[1/6] MNIST dataset")
    (x_train_raw, y_train), (x_test_raw, y_test) = load_mnist_data()

    x_train = np.array(x_train_raw) / 255.0
    x_test = np.array(x_test_raw) / 255.0

    print(f"   Training samples: {x_train.shape[0]}")
    print(f"   Test samples: {x_test.shape[0]}")

    print("\n[2/6] Plotting LTP/LTD curves")
    me_model = MEModel()
    plot_ltp_ltd_curves(me_model)

    print("\n[3/6] Initializing neural network")
    neural_net = MENeuralNetwork(input_size=784, hidden_size=128, output_size=10)
    print("   Network architecture: 784 → 128 → 10")

    print("\n[4/6] Starting training")
    print("-" * 70)
    result = neural_net.train(
        x_train, y_train, x_test, y_test,
        epochs=350, batch_size=512, learning_rate=0.12
    )
    train_loss_hist, train_acc_hist, test_loss_hist, test_acc_hist = result
    print("-" * 70)

    print("\n[5/6] Training curve")
    plot_training_curves(train_acc_hist, test_acc_hist)

    print("\n[6/6] confusion matrix")
    final_predictions = neural_net.predict(x_test)
    confusion_mat = plot_confusion_matrix_heatmap(y_test, final_predictions)

    print("\n training data")

    txt_path = os.path.join(OUTPUT_DIR, 'training_data.txt')
    with open(txt_path, 'w', encoding='utf-8') as txt_file:
        txt_file.write("=" * 70 + "\n")
        txt_file.write("ME Neural Network Training Results\n")
        txt_file.write("=" * 70 + "\n\n")

        txt_file.write("【Final Results】\n")
        txt_file.write(f"Final Train Accuracy: {train_acc_hist[-1]:.6f} ({train_acc_hist[-1] * 100:.2f}%)\n")
        txt_file.write(f"Final Train Loss:     {train_loss_hist[-1]:.6f}\n")

        txt_file.write("=" * 70 + "\n")
        txt_file.write("【Training History】\n")
        txt_file.write("=" * 70 + "\n")
        txt_file.write(f"{'Epoch':<8}{'Train Acc':<15}{'Test Acc':<15}\n")
        txt_file.write("-" * 70 + "\n")

        for epoch in range(len(train_loss_hist)):
            txt_file.write(f"{epoch + 1:<8}"
                           f"{train_acc_hist[epoch]:<15.6f}"
                           f"{test_acc_hist[epoch]:<15.6f}\n")

        txt_file.write("\n" + "=" * 70 + "\n")
        txt_file.write("【Confusion Matrix】\n")
        txt_file.write("=" * 70 + "\n")
        txt_file.write("       Predicted →\n")
        txt_file.write("True ↓  " + "  ".join([f"{i:>5}" for i in range(10)]) + "\n")
        txt_file.write("-" * 70 + "\n")

        for i in range(10):
            txt_file.write(f"  {i}    ")
            txt_file.write("  ".join([f"{confusion_mat[i, j]:>5}" for j in range(10)]))
            txt_file.write("\n")

        txt_file.write("All data saved successfully\n")

    print("Training Complete")



if __name__ == "__main__":
    main()
